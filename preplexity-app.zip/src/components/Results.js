import React, { useState } from "react";
import { Textarea, Button } from "@nextui-org/react";
import Layout from "./Layout";

const Results = () => {
  const [textareaValue, setTextareaValue] = useState("");
  const [textHeight, setTextHeight] = useState(false);

  const handleTextareaChange = (e) => {
    setTextareaValue(e.target.value);
  };

  const checkHeight = (height) => {
    console.log("first", height);
    if (height >= 48) {
      setTextHeight(true);
    } else {
      setTextHeight(false);
    }
  };

  return (
    <Layout>
      <div className="rounded-md cw-m col-span-4 border border-pxty-border-color bg-pxty-chat-bg grid grid-cols-10">
        <div className="col-span-1"> </div>
        {/* ------- main content */}
        <div className="col-span-5 relative">
          <div className="my-8 text-3xl text-pxty-hg">What is react?</div>
          <div className="flex items-center mb-3">
            <span className="mr-2">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 20 20"
                fill="currentColor"
                className="w-5 h-5"
              >
                <path
                  fillRule="evenodd"
                  d="M9 3.5a5.5 5.5 0 1 0 0 11 5.5 5.5 0 0 0 0-11ZM2 9a7 7 0 1 1 12.452 4.391l3.328 3.329a.75.75 0 1 1-1.06 1.06l-3.329-3.328A7 7 0 0 1 2 9Z"
                  clipRule="evenodd"
                />
              </svg>
            </span>
            <span className="text-lg text-pxty-hg font-medium">Answer</span>
          </div>
          <div className="text-base text-pxty-hg font-normal">
            React is a JavaScript library for building user interfaces. It was
            created by Facebook and is widely used in web development[2][4].
            React allows developers to build UI components and create fast,
            efficient, and scalable web applications[3]. It can be used for the
            development of both web and mobile apps, as there is a framework
            called React Native, derived from React itself, that is hugely
            popular and is used for creating beautiful mobile applications[2].
            React makes it easy to create interactive UIs by designing simple
            views for each state in your application, and React will efficiently
            update and render just the right components when your data
            changes[5].
          </div>
          <div
            className={`bg-pxty-grey fixed bottom-[5%] ${
              textHeight ? "rounded-md" : "rounded-full"
            } w-[40%] p-2`}
          >
            <div
              className={`flex items-center justify-between w-full border border-pxty-border-color ${
                textHeight ? "rounded-md" : "rounded-full"
              }`}
            >
              <div className="mx-2">
                <Button isIconOnly className="contents">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    strokeWidth={2}
                    stroke="currentColor"
                    className="w-6 h-6"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M12 9v6m3-3H9m12 0a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z"
                    />
                  </svg>
                </Button>
              </div>
              <Textarea
                value={textareaValue}
                onChange={handleTextareaChange}
                onHeightChange={checkHeight}
                //   rows={1}
                minRows={1}
                placeholder="Ask anything..."
                classNames={{
                  inputWrapper: ["bg-pxty-grey", "p-0"],
                  input: [
                    "bg-pxty-grey",
                    "placeholder:text-pxty-text-color",
                    "text-white",
                    "text-base",
                  ],
                  innerWrapper: [
                    "bg-pxty-grey",
                    "placeholder:text-pxty-text-color",
                    "rounded-md",
                    "text-white",
                    "text-base",
                  ],
                  base: ["bg-pxty-grey", "m-[1%]"],
                }}
              />
              <div className="mx-2">
                <Button isIconOnly className="contents">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 24 24"
                    fill="#333332"
                    className="w-8 h-8"
                  >
                    <path
                      fillRule="evenodd"
                      d="M12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25Zm.53 5.47a.75.75 0 0 0-1.06 0l-3 3a.75.75 0 1 0 1.06 1.06l1.72-1.72v5.69a.75.75 0 0 0 1.5 0v-5.69l1.72 1.72a.75.75 0 1 0 1.06-1.06l-3-3Z"
                      clipRule="evenodd"
                      stroke="#60605F"
                    />
                  </svg>
                </Button>
              </div>
            </div>
          </div>
        </div>
        {/* images---- */}
        <div className="col-span-4"></div>
      </div>
    </Layout>
  );
};

export default Results;
