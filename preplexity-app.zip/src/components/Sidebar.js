import { Image } from "@nextui-org/image";
import { Input, Button } from "@nextui-org/react";
import React from "react";
import Logo from "../images/Perplexity_AI_logo.svg.png";
import { useNavigate } from "react-router-dom";

const Sidebar = () => {
  const navigate = useNavigate();
  const navigateHome = () => {
    navigate("/home");
  };
  return (
    <div className="height h-full col-span-1">
      <div className="flex items-center gap-x-1  p-4">
        <Image src={Logo} width="34px" height="34px" />
        <span className="font-extralight text-white text-3xl">perplexity</span>
      </div>
      <div className="my-4 text-white px-4">
        <Input
          className="border border-3 border-pxty-border-color hover:border-white rounded-full"
          radius="full"
          placeholder="New Thread"
          labelPlacement="outside"
          classNames={{
            inputWrapper: [
              "bg-pxty-chat-bg",
              "hover:bg-pxty-chat-bg",
              "focus:bg-pxty-chat-bg",
            ],
            input: [
              "bg-pxty-chat-bg",
              "hover:bg-pxty-chat-bg",
              "focus:bg-pxty-chat-bg",
              "placeholder:text-pxty-text-color",
            ],
            base: "input-base",
          }}
          endContent={
            <>
              <span>x</span>
              <span>k</span>
            </>
          }
        />
      </div>
      <div className="px-1">
        <Button
          onClick={navigateHome}
          className="width w-full bg-pxty-grey text-pxty-text-color text-base justify-start hover:bg-white"
          startContent={
            <span>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 20 20"
                fill="currentColor"
                className="w-5 h-5"
              >
                <path
                  fillRule="evenodd"
                  d="M9 3.5a5.5 5.5 0 1 0 0 11 5.5 5.5 0 0 0 0-11ZM2 9a7 7 0 1 1 12.452 4.391l3.328 3.329a.75.75 0 1 1-1.06 1.06l-3.329-3.328A7 7 0 0 1 2 9Z"
                  clipRule="evenodd"
                />
              </svg>
            </span>
          }
        >
          Home
        </Button>
        <Button
          className="width w-full bg-pxty-grey text-pxty-text-color text-base justify-start hover:bg-white"
          startContent={
            <span>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 20 20"
                fill="currentColor"
                className="w-5 h-5"
              >
                <path
                  fillRule="evenodd"
                  d="M9 3.5a5.5 5.5 0 1 0 0 11 5.5 5.5 0 0 0 0-11ZM2 9a7 7 0 1 1 12.452 4.391l3.328 3.329a.75.75 0 1 1-1.06 1.06l-3.329-3.328A7 7 0 0 1 2 9Z"
                  clipRule="evenodd"
                />
              </svg>
            </span>
          }
        >
          Discover
        </Button>
        <Button
          className="width w-full bg-pxty-grey text-pxty-text-color text-base justify-start hover:bg-white"
          startContent={
            <span>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 20 20"
                fill="currentColor"
                className="w-5 h-5"
              >
                <path
                  fillRule="evenodd"
                  d="M9 3.5a5.5 5.5 0 1 0 0 11 5.5 5.5 0 0 0 0-11ZM2 9a7 7 0 1 1 12.452 4.391l3.328 3.329a.75.75 0 1 1-1.06 1.06l-3.329-3.328A7 7 0 0 1 2 9Z"
                  clipRule="evenodd"
                />
              </svg>
            </span>
          }
        >
          Library
        </Button>
      </div>
    </div>
  );
};

export default Sidebar;
