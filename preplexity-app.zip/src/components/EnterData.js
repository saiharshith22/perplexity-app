import React from "react";
import { Textarea, Button } from "@nextui-org/react";
import { useNavigate } from "react-router-dom";
import Layout from "./Layout";

const EnterData = () => {
  const navigate = useNavigate();
  const handleSearch = () => {
    navigate("/results");
  };
  return (
    <Layout>
      <div className="rounded-md cw-m col-span-4 border border-pxty-border-color bg-pxty-chat-bg flex justify-center items-center">
        <div className="w-7/12">
          <div className="text-pxty-hg text-4xl pb-1 mb-8 text-center">
            Where knowledge begins
          </div>
          <div className="border border-pxty-border-color rounded-md bg-pxty-grey">
            <div className="px-4 pt-4">
              <Textarea
                placeholder="Ask anything..."
                classNames={{
                  inputWrapper: [
                    "bg-pxty-grey",
                    "hover:bg-pxty-grey",
                    "focus:bg-pxty-grey",
                    "rounded-md",
                    "p-0",
                  ],
                  input: [
                    "bg-pxty-grey",
                    "hover:bg-pxty-grey",
                    "focus:bg-pxty-grey",
                    "placeholder:text-pxty-text-color",
                    "rounded-md",
                    "text-white",
                    "text-base",
                  ],
                }}
              />
            </div>
            <div className="flex justify-between">
              <div className="pb-2 pl-2">
                <Button
                  className="bg-pxty-grey text-pxty-text-color p-0 h-fit text-sm h-8"
                  radius="full"
                  startContent={
                    <span>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 24 24"
                        fill="currentColor"
                        className="w-5 h-5"
                      >
                        <path
                          fillRule="evenodd"
                          d="M3 6.75A.75.75 0 0 1 3.75 6h16.5a.75.75 0 0 1 0 1.5H3.75A.75.75 0 0 1 3 6.75ZM3 12a.75.75 0 0 1 .75-.75h16.5a.75.75 0 0 1 0 1.5H3.75A.75.75 0 0 1 3 12Zm0 5.25a.75.75 0 0 1 .75-.75H12a.75.75 0 0 1 0 1.5H3.75a.75.75 0 0 1-.75-.75Z"
                          clipRule="evenodd"
                        />
                      </svg>
                    </span>
                  }
                >
                  Focus
                </Button>
                <Button
                  className="bg-pxty-grey text-pxty-text-color p-0 h-fit text-sm h-8"
                  radius="full"
                  startContent={
                    <span>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                        strokeWidth={2}
                        stroke="currentColor"
                        className="w-5 h-5"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M12 9v6m3-3H9m12 0a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z"
                        />
                      </svg>
                    </span>
                  }
                >
                  Attach
                </Button>
              </div>
              <Button
                onClick={handleSearch}
                isIconOnly
                className="bg-pxty-grey text-pxty-text-color p-0 h-fit text-sm h-8"
                radius="full"
                startContent={
                  <span>
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      fill="none"
                      viewBox="0 0 24 24"
                      strokeWidth={1.5}
                      stroke="currentColor"
                      className="w-8 h-8"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        d="m12.75 15 3-3m0 0-3-3m3 3h-7.5M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z"
                      />
                    </svg>
                  </span>
                }
              ></Button>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};
export default EnterData;
