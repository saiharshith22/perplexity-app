import "./App.css";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import EnterData from "./components/EnterData";
import Results from "./components/Results";
import LoginPage from "./components/LoginPage";

function App() {
  return (
    <div className="bg-pxty-grey h-screen text-pxty-text-color">
      <Router>
        <Routes>
          <Route path="/" exact element={<LoginPage />} />
          <Route path="/home" exact element={<EnterData />} />
          <Route path="/results" exact element={<Results />} />
        </Routes>
      </Router>
    </div>
  );
}

export default App;
